library(testthat)
library(finalfit)

test_check("finalfit")
